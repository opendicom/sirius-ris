## Text alignment and RTL content

1. The editor should run in RTL mode.
1. Paragraphs in the content should be aligned according to the text inside.
1. See the toolbar (dropdown) icon as you travel across the document with your caret. The icon should reflect the alignment (default is **right**).
1. You should be able to use the dropdown to change the alignment of existing and new text.
