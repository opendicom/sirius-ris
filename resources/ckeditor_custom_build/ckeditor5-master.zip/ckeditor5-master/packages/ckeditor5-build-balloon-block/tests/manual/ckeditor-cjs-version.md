# CKEditor 5 balloon block editor build – standard version (CommonJS `require()`)

Just play with it.

**Note:** Remember to rebuild the bundles by running `npm run build` in build's package directory. You can also run Webpack in the watch mode:

```
./node_modules/.bin/webpack -w
```
